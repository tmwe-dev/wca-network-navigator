// ══════════════════════════════════════════════
// WhatsApp Extension - Background Service Worker v4
// Self-Healing DOM: learns selectors via AI, caches them,
// auto-relearns when they break. Zero hardcoded selectors.
// ══════════════════════════════════════════════

const WA_BASE = "https://web.whatsapp.com";

const APP_URL_PATTERNS = [
  /^https:\/\/[^/]*\.lovable\.app\//i,
  /^https:\/\/[^/]*\.lovableproject\.com\//i,
  /^https?:\/\/localhost(?::\d+)?\//i,
  /^https?:\/\/127\.0\.0\.1(?::\d+)?\//i,
];

function isAppUrl(url) {
  return typeof url === "string" && APP_URL_PATTERNS.some((p) => p.test(url));
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ══════════════════════════════════════════════
//  DOM SCHEMA CACHE — Self-healing selectors
// ══════════════════════════════════════════════

const SCHEMA_CACHE_KEY = "wa_dom_schema";
const SCHEMA_TTL_MS = 3 * 60 * 60 * 1000; // 3 hours

// Default selectors (best-effort, used ONLY until first AI learn succeeds)
const FALLBACK_SCHEMA = {
  sidebar: "#pane-side",
  chatList: '[data-testid="chatlist"]',
  chatItem: '[data-testid="cell-frame-container"]',
  chatItemAlt: '[role="listitem"]',
  chatTitle: 'span[title]',
  unreadBadge: '[data-testid="icon-unread-count"]',
  lastMessage: '[data-testid="last-msg-status"]',
  timeStamp: '[data-testid="cell-frame-primary-detail"]',
  searchBox: '[data-testid="chat-list-search"]',
  conversationPanel: '[data-testid="conversation-panel-messages"]',
  msgContainer: '[data-testid="msg-container"]',
  msgText: '[data-testid="balloon-text"] span',
  msgMeta: '[data-testid="msg-meta"] span',
  msgOutCheck: '[data-testid="msg-dblcheck"]',
  msgOutSingle: '[data-testid="msg-check"]',
  qrCode: 'canvas[aria-label], [data-testid="qrcode"]',
  mainHeader: '#main header span[title]',
  composeBox: '[data-testid="conversation-compose-box-input"]',
  sendButton: '[data-testid="send"], button[aria-label*="Invia"], button[aria-label*="Send"]',
  searchClear: '[data-testid="search-input-clear"], [data-testid="x-alt"], [data-testid="search-close"]',
  learnedAt: 0,
};

async function getCachedSchema() {
  try {
    var data = await chrome.storage.local.get([SCHEMA_CACHE_KEY]);
    var schema = data[SCHEMA_CACHE_KEY];
    if (schema && schema.learnedAt && (Date.now() - schema.learnedAt < SCHEMA_TTL_MS)) {
      return schema;
    }
  } catch (_) {}
  return null;
}

async function saveCachedSchema(schema) {
  schema.learnedAt = Date.now();
  try {
    await chrome.storage.local.set({ [SCHEMA_CACHE_KEY]: schema });
  } catch (_) {}
}

async function getSchema() {
  var cached = await getCachedSchema();
  if (cached) return cached;
  return Object.assign({}, FALLBACK_SCHEMA);
}

// ══════════════════════════════════════════════
//  LEARN DOM via AI — the core self-healing engine
// ══════════════════════════════════════════════

async function learnDomViaAI(tabId) {
  var config = await getConfig();
  if (!config.supabaseUrl || !config.anonKey) {
    return { success: false, error: "Supabase config not available for DOM learning" };
  }

  // Grab a structured snapshot of the page for AI analysis
  var snapResult = await chrome.scripting.executeScript({
    target: { tabId },
    func: function() {
      // Grab key structural info without sending full HTML (too big)
      var snap = {};

      // 1. All data-testid attributes on the page
      var testIds = new Set();
      document.querySelectorAll("[data-testid]").forEach(function(el) {
        testIds.add(el.getAttribute("data-testid"));
      });
      snap.testIds = Array.from(testIds).sort();

      // 2. All role attributes
      var roles = {};
      document.querySelectorAll("[role]").forEach(function(el) {
        var r = el.getAttribute("role");
        roles[r] = (roles[r] || 0) + 1;
      });
      snap.roles = roles;

      // 3. All aria-label attributes
      var labels = new Set();
      document.querySelectorAll("[aria-label]").forEach(function(el) {
        labels.add(el.getAttribute("aria-label"));
      });
      snap.ariaLabels = Array.from(labels).slice(0, 100);

      // 4. IDs on the page
      var ids = new Set();
      document.querySelectorAll("[id]").forEach(function(el) {
        ids.add(el.id);
      });
      snap.ids = Array.from(ids).sort();

      // 5. Sample the sidebar structure (first 3000 chars of the largest panel)
      var panels = Array.from(document.querySelectorAll("div")).filter(function(d) {
        return d.children.length > 3 && d.scrollHeight > 300;
      }).sort(function(a, b) { return b.children.length - a.children.length; });
      
      if (panels.length > 0) {
        snap.sidebarSample = panels[0].outerHTML.slice(0, 3000);
      }

      // 6. Sample a chat item if any repetitive structure exists
      var repeatedContainers = Array.from(document.querySelectorAll("div")).filter(function(d) {
        if (d.children.length < 5) return false;
        var tags = new Set();
        for (var c of d.children) tags.add(c.tagName + "." + c.className.split(" ").sort().join("."));
        return tags.size <= 3; // mostly same structure = list
      }).sort(function(a, b) { return b.children.length - a.children.length; });
      
      if (repeatedContainers.length > 0) {
        var firstItem = repeatedContainers[0].children[0];
        snap.chatItemSample = firstItem ? firstItem.outerHTML.slice(0, 2000) : null;
        snap.chatItemCount = repeatedContainers[0].children.length;
        snap.chatItemParentSelector = "";
        // Build a selector path for the parent
        var el = repeatedContainers[0];
        var parts = [];
        while (el && el !== document.body && parts.length < 5) {
          var s = el.tagName.toLowerCase();
          if (el.id) s += "#" + el.id;
          else if (el.getAttribute("data-testid")) s += '[data-testid="' + el.getAttribute("data-testid") + '"]';
          else if (el.getAttribute("role")) s += '[role="' + el.getAttribute("role") + '"]';
          parts.unshift(s);
          el = el.parentElement;
        }
        snap.chatItemParentSelector = parts.join(" > ");
      }

      // 7. Search-related elements
      var editables = document.querySelectorAll('[contenteditable="true"]');
      snap.editableCount = editables.length;
      snap.editableContexts = Array.from(editables).slice(0, 5).map(function(e) {
        var parent = e.parentElement;
        var ctx = e.tagName;
        if (e.getAttribute("data-testid")) ctx += '[data-testid="' + e.getAttribute("data-testid") + '"]';
        if (parent) {
          ctx += " inside " + parent.tagName;
          if (parent.getAttribute("data-testid")) ctx += '[data-testid="' + parent.getAttribute("data-testid") + '"]';
        }
        return ctx;
      });

      // 8. Message area sample
      var mainEl = document.querySelector("#main") || document.querySelector('[data-testid="conversation-panel-wrapper"]');
      if (mainEl) {
        snap.mainSample = mainEl.outerHTML.slice(0, 2000);
      }

      return { success: true, snapshot: snap };
    },
  });

  var snap = snapResult?.[0]?.result;
  if (!snap?.success) return { success: false, error: "Failed to capture DOM snapshot" };

  // Send to AI for selector mapping
  var url = config.supabaseUrl + "/functions/v1/whatsapp-ai-extract";
  var headers = {
    "Content-Type": "application/json",
    "apikey": config.anonKey,
  };
  if (config.authToken) headers["Authorization"] = "Bearer " + config.authToken;
  else headers["Authorization"] = "Bearer " + config.anonKey;

  var systemPrompt = `You are a WhatsApp Web DOM analyst. Given a structural snapshot of WhatsApp Web's current DOM, identify the correct CSS selectors for each UI element.

Return a JSON object with these exact keys (each value is a CSS selector string):
- sidebar: the main sidebar container (chat list panel)
- chatList: the scrollable chat list container
- chatItem: selector for individual chat items in the sidebar
- chatItemAlt: alternative selector for chat items
- chatTitle: the element inside a chat item that contains the contact name
- unreadBadge: the badge showing unread message count
- lastMessage: the element showing the last message preview
- timeStamp: the element showing the message time
- searchBox: the search input/box at the top
- conversationPanel: the panel containing messages in an open chat
- msgContainer: individual message bubbles/containers
- msgText: the text content inside a message
- msgMeta: timestamp/meta info inside a message
- msgOutCheck: indicator for sent messages (double check)
- msgOutSingle: indicator for sent messages (single check)
- qrCode: QR code element (for login detection)
- mainHeader: the header of the open chat showing contact name
- composeBox: the message input box in an open chat
- sendButton: the send button
- searchClear: button to clear search

Use data-testid selectors when available. Use role, aria-label, or structural selectors as fallback.
If you cannot determine a selector, use the best guess based on the structure.
Return ONLY valid JSON, no markdown, no explanation.`;

  try {
    // We reuse the whatsapp-ai-extract endpoint but with a special mode
    var resp = await fetch(url, {
      method: "POST",
      headers: headers,
      body: JSON.stringify({
        html: JSON.stringify(snap.snapshot),
        mode: "learnDom",
      }),
    });

    if (!resp.ok) {
      console.warn("[WA DOM Learn] AI error:", resp.status);
      return { success: false, error: "AI returned " + resp.status };
    }

    var data = await resp.json();
    var schema = null;

    // The edge function returns items, but for learnDom we need to handle differently
    // Since we're reusing the endpoint, we'll parse the content
    if (data.items && data.items.length > 0) {
      schema = data.items[0]; // AI should return a single object
    }
    
    if (!schema || typeof schema !== "object") {
      // Try the raw snapshot-based approach: use what we found
      schema = buildSchemaFromSnapshot(snap.snapshot);
    }

    if (schema) {
      schema.learnedAt = Date.now();
      await saveCachedSchema(schema);
      console.log("[WA DOM Learn] ✅ Learned and cached", Object.keys(schema).length, "selectors");
      return { success: true, schema: schema };
    }

    return { success: false, error: "Could not parse AI response" };
  } catch (e) {
    console.error("[WA DOM Learn] Error:", e);
    return { success: false, error: e.message };
  }
}

// Build schema directly from the snapshot data without AI
function buildSchemaFromSnapshot(snapshot) {
  if (!snapshot) return null;
  var s = Object.assign({}, FALLBACK_SCHEMA);
  var testIds = snapshot.testIds || [];
  var ids = snapshot.ids || [];

  // Update selectors based on what actually exists
  function findTestId(pattern) {
    return testIds.find(function(t) { return t.includes(pattern); });
  }

  // Sidebar
  if (ids.includes("pane-side")) s.sidebar = "#pane-side";
  else if (ids.includes("side")) s.sidebar = "#side";
  else {
    var chatlistId = findTestId("chatlist") || findTestId("chat-list");
    if (chatlistId) s.sidebar = '[data-testid="' + chatlistId + '"]';
  }

  // Chat list
  var chatlistTestId = findTestId("chatlist") || findTestId("chat-list");
  if (chatlistTestId) s.chatList = '[data-testid="' + chatlistTestId + '"]';
  
  // Chat items
  var cellFrame = findTestId("cell-frame-container") || findTestId("cell-frame") || findTestId("chat-cell");
  if (cellFrame) s.chatItem = '[data-testid="' + cellFrame + '"]';
  else if (snapshot.chatItemParentSelector) {
    s.chatItem = snapshot.chatItemParentSelector + " > *";
  }

  // Search
  var searchTestId = findTestId("chat-list-search") || findTestId("search");
  if (searchTestId) s.searchBox = '[data-testid="' + searchTestId + '"]';

  // Conversation
  var convPanel = findTestId("conversation-panel-messages") || findTestId("conversation-panel");
  if (convPanel) s.conversationPanel = '[data-testid="' + convPanel + '"]';

  // Messages
  var msgCont = findTestId("msg-container") || findTestId("message-in") || findTestId("message-out");
  if (msgCont) s.msgContainer = '[data-testid="' + msgCont + '"]';

  var balloonText = findTestId("balloon-text");
  if (balloonText) s.msgText = '[data-testid="' + balloonText + '"] span';

  var msgMeta = findTestId("msg-meta");
  if (msgMeta) s.msgMeta = '[data-testid="' + msgMeta + '"] span';

  // Unread
  var unread = findTestId("icon-unread-count") || findTestId("unread");
  if (unread) s.unreadBadge = '[data-testid="' + unread + '"]';

  // Compose
  var compose = findTestId("conversation-compose-box-input") || findTestId("compose");
  if (compose) s.composeBox = '[data-testid="' + compose + '"]';

  // Send button
  var send = findTestId("send");
  if (send) s.sendButton = '[data-testid="' + send + '"]';

  // QR
  var qr = findTestId("qrcode") || findTestId("qr");
  if (qr) s.qrCode = '[data-testid="' + qr + '"]';
  
  // Search clear
  var clear = findTestId("search-input-clear") || findTestId("x-alt") || findTestId("search-close");
  if (clear) s.searchClear = '[data-testid="' + clear + '"]';

  return s;
}

// ══════════════════════════════════════════════
//  CORE HELPERS (tab management, injection)
// ══════════════════════════════════════════════

async function injectBridgeIntoFrame(tabId, frameId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      files: ["content.js"],
    });
    return true;
  } catch (error) {
    var msg = error?.message || "";
    if (msg.includes("Cannot access") || msg.includes("Missing host") || msg.includes("No frame") || msg.includes("Frame with ID") || msg.includes("gallery")) return false;
    return false;
  }
}

async function injectBridgeIntoTab(tabId) {
  try {
    var frames = await chrome.webNavigation.getAllFrames({ tabId });
    if (!frames?.length) return false;
    var injected = false;
    for (var f of frames) {
      if (!isAppUrl(f.url)) continue;
      var ok = await injectBridgeIntoFrame(tabId, f.frameId);
      injected = ok || injected;
    }
    return injected;
  } catch (_) { return false; }
}

async function syncBridgeAcrossOpenTabs() {
  try {
    var tabs = await chrome.tabs.query({});
    for (var t of tabs) {
      if (typeof t.id !== "number") continue;
      await injectBridgeIntoTab(t.id);
    }
  } catch (_) {}
}

async function safeCreateTab(url, active) {
  for (var i = 0; i < 3; i++) {
    try { return await chrome.tabs.create({ url, active: active || false }); }
    catch (e) { if (i < 2) await sleep(500 * (i + 1)); else throw e; }
  }
}

async function waitForLoad(tabId, timeoutMs) {
  var start = Date.now();
  while (Date.now() - start < (timeoutMs || 30000)) {
    try {
      var tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return true;
    } catch (_) { return false; }
    await sleep(500);
  }
  return false;
}

async function getOrCreateWaTab() {
  try {
    var tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (tabs.length > 0) {
      var tab = tabs[0];
      if (tab.status === "complete") return { tab, reused: true };
      await waitForLoad(tab.id, 15000);
      return { tab, reused: true };
    }
  } catch (_) {}
  var tab = await safeCreateTab(WA_BASE, false);
  var loaded = await waitForLoad(tab.id, 30000);
  if (!loaded) throw new Error("WhatsApp Web non caricato");
  await sleep(4000);
  return { tab, reused: false };
}

async function getConfig() {
  try {
    var data = await chrome.storage.local.get(["supabaseUrl", "anonKey", "authToken"]);
    return data;
  } catch (_) { return {}; }
}

// ══════════════════════════════════════════════
//  SELECTOR-AWARE DOM OPERATIONS
//  All operations use the learned schema
// ══════════════════════════════════════════════

// Generic: grab HTML from any selector, with fallback chain
async function grabHtml(tabId, selectorOrChain) {
  var selectors = Array.isArray(selectorOrChain) ? selectorOrChain : [selectorOrChain];
  var results = await chrome.scripting.executeScript({
    target: { tabId },
    args: [selectors],
    func: function(sels) {
      for (var s of sels) {
        if (!s) continue;
        var el = document.querySelector(s);
        if (el) return el.outerHTML;
      }
      return null;
    },
  });
  return results?.[0]?.result || null;
}

// Call AI edge function for HTML extraction
async function callAiExtract(html, mode, supabaseUrl, anonKey, authToken) {
  try {
    var url = supabaseUrl + "/functions/v1/whatsapp-ai-extract";
    var headers = { "Content-Type": "application/json", "apikey": anonKey };
    if (authToken) headers["Authorization"] = "Bearer " + authToken;
    else headers["Authorization"] = "Bearer " + anonKey;

    var resp = await fetch(url, {
      method: "POST",
      headers: headers,
      body: JSON.stringify({ html, mode }),
    });
    if (!resp.ok) { console.warn("[WA AI] Error:", resp.status); return null; }
    return await resp.json();
  } catch (e) { console.warn("[WA AI] Fetch failed:", e.message); return null; }
}

// ── Verify Session (uses schema) ──
async function verifySession() {
  try {
    var tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    var tabId;
    if (tabs.length > 0) {
      tabId = tabs[0].id;
      if (tabs[0].status !== "complete") await waitForLoad(tabId, 8000);
    } else {
      var r = await getOrCreateWaTab();
      tabId = r.tab.id;
      await sleep(3000);
    }
    
    var schema = await getSchema();
    for (var attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) await sleep(2000);
      try {
        var results = await chrome.scripting.executeScript({
          target: { tabId },
          args: [schema],
          func: function(s) {
            // QR check
            var qrSels = (s.qrCode || "").split(",").map(function(x){return x.trim();});
            for (var q of qrSels) {
              if (q && document.querySelector(q)) return { success: true, authenticated: false, reason: "qr_required" };
            }
            // Authenticated check: sidebar or chat list
            if (document.querySelector(s.sidebar) || document.querySelector(s.chatList) || document.querySelector("#side") || document.querySelector("#pane-side"))
              return { success: true, authenticated: true };
            if (document.querySelector('[data-testid="intro-md-beta-logo"]') || document.querySelector('.landing-window'))
              return { success: true, authenticated: false, reason: "loading" };
            return null;
          },
        });
        var result = results?.[0]?.result;
        if (result) return result;
      } catch (_) {}
    }
    return { success: true, authenticated: false, reason: "unknown_state" };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Read Unread (schema-aware + AI fallback) ──
async function readUnreadDOM(tabId, schema) {
  var results = await chrome.scripting.executeScript({
    target: { tabId },
    args: [schema],
    func: function(s) {
      var VERIFY_COUNT = 5;
      
      // QR check
      var qrSels = (s.qrCode || "").split(",").map(function(x){return x.trim();});
      for (var q of qrSels) {
        if (q && document.querySelector(q)) return { success: false, error: "QR code visibile - accedi a WhatsApp Web" };
      }

      var messages = [];
      
      // Try multiple selector strategies for chat items
      var chatItems = [];
      var selectors = [s.chatItem, s.chatItemAlt, '[role="listitem"]', '[role="row"]', '[tabindex="-1"]'];
      
      for (var sel of selectors) {
        if (!sel) continue;
        // If selector needs a parent context, try with sidebar
        var items = document.querySelectorAll(sel);
        if (items.length > 2) { chatItems = items; break; }
        
        // Try within sidebar
        var sidebar = document.querySelector(s.sidebar) || document.querySelector(s.chatList) || document.querySelector("#pane-side") || document.querySelector("#side");
        if (sidebar) {
          items = sidebar.querySelectorAll(sel);
          if (items.length > 2) { chatItems = items; break; }
        }
      }

      // Last resort: find the largest list-like container
      if (chatItems.length === 0) {
        var containers = Array.from(document.querySelectorAll("div")).filter(function(d) {
          return d.children.length > 5 && d.scrollHeight > 300;
        }).sort(function(a, b) { return b.children.length - a.children.length; });
        
        if (containers.length > 0) {
          chatItems = containers[0].children;
        }
      }

      var processed = 0;
      for (var chat of chatItems) {
        // Unread badge
        var badge = null;
        var badgeSels = [s.unreadBadge, 'span[aria-label*="non lett"]', 'span[aria-label*="unread"]'];
        for (var bs of badgeSels) {
          if (!bs) continue;
          badge = chat.querySelector(bs);
          if (badge) break;
        }
        var count = 0;
        if (badge) { count = parseInt(badge.textContent) || 1; }
        else {
          var spans = chat.querySelectorAll("span");
          for (var sp of spans) {
            var bg = window.getComputedStyle(sp).backgroundColor;
            var txt = sp.textContent.trim();
            if (txt && /^\d+$/.test(txt) && bg && (bg.includes("37, 211") || bg.includes("25d366") || bg.includes("00a884"))) {
              count = parseInt(txt) || 1; break;
            }
          }
        }

        var isVerify = processed < VERIFY_COUNT;
        if (count === 0 && !isVerify) continue;

        // Title
        var titleEl = null;
        var titleSels = [s.chatTitle, 'span[title][dir="auto"]', 'span[title]'];
        for (var ts of titleSels) {
          if (!ts) continue;
          titleEl = chat.querySelector(ts);
          if (titleEl) break;
        }

        // Last message
        var lastMsgEl = null;
        var msgSels = [s.lastMessage, 'span[title]'];
        for (var ms of msgSels) {
          if (!ms) continue;
          lastMsgEl = chat.querySelector(ms);
          // Don't use the title element as last message
          if (lastMsgEl === titleEl) lastMsgEl = null;
          if (lastMsgEl) break;
        }

        // Time
        var timeEl = chat.querySelector(s.timeStamp);

        messages.push({
          contact: titleEl?.getAttribute("title") || titleEl?.textContent?.trim() || "Sconosciuto",
          lastMessage: lastMsgEl?.textContent?.trim() || "",
          time: timeEl?.textContent?.trim() || new Date().toISOString(),
          unreadCount: count,
          isVerify: isVerify && count === 0,
        });
        processed++;
      }
      return { success: true, messages: messages, scanned: chatItems.length };
    },
  });
  return results?.[0]?.result || { success: false, error: "No result" };
}

async function readUnreadMessages() {
  try {
    var r = await getOrCreateWaTab();
    var tab = r.tab;
    await sleep(r.reused ? 1500 : 5000);

    // Login check
    var schema = await getSchema();
    var loginCheck = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [schema],
      func: function(s) {
        var qrSels = (s.qrCode || "").split(",").map(function(x){return x.trim();});
        for (var q of qrSels) { if (q && document.querySelector(q)) return true; }
        return false;
      }
    });
    if (loginCheck?.[0]?.result) {
      return { success: false, error: "WhatsApp Web non connesso - scansiona il QR code" };
    }

    // Try AI extraction first
    var config = await getConfig();
    if (config.supabaseUrl && config.anonKey) {
      var sidebarHtml = await grabHtml(tab.id, [schema.sidebar, schema.chatList, "#pane-side", "#side"]);
      if (sidebarHtml && sidebarHtml.length > 100) {
        console.log("[WA] Sending " + sidebarHtml.length + " chars to AI for extraction");
        var aiResult = await callAiExtract(sidebarHtml, "sidebar", config.supabaseUrl, config.anonKey, config.authToken);
        if (aiResult?.success && aiResult.items?.length > 0) {
          console.log("[WA] AI extracted " + aiResult.items.length + " unread chats");
          return {
            success: true,
            messages: aiResult.items.map(function(item) {
              return {
                contact: item.contact || "Sconosciuto",
                lastMessage: item.lastMessage || "",
                time: item.time || new Date().toISOString(),
                unreadCount: item.unreadCount || 1,
              };
            }),
            scanned: 0,
            method: "ai",
          };
        }
        console.log("[WA] AI returned 0 items, falling back to DOM");
      } else {
        console.log("[WA] Sidebar HTML not found with cached selectors, triggering re-learn");
        // Auto-heal: trigger DOM learning
        await learnDomViaAI(tab.id);
        schema = await getSchema();
        // Retry grab with new selectors
        sidebarHtml = await grabHtml(tab.id, [schema.sidebar, schema.chatList]);
        if (sidebarHtml && sidebarHtml.length > 100) {
          var aiResult2 = await callAiExtract(sidebarHtml, "sidebar", config.supabaseUrl, config.anonKey, config.authToken);
          if (aiResult2?.success && aiResult2.items?.length > 0) {
            return {
              success: true,
              messages: aiResult2.items.map(function(item) {
                return { contact: item.contact || "Sconosciuto", lastMessage: item.lastMessage || "", time: item.time || "", unreadCount: item.unreadCount || 1 };
              }),
              scanned: 0,
              method: "ai-relearned",
            };
          }
        }
      }
    }

    // Fallback to DOM selectors
    console.log("[WA] Using DOM fallback for readUnread");
    var domResult = await readUnreadDOM(tab.id, schema);
    
    // If DOM also found 0 chats, attempt re-learn for next time
    if (domResult.success && domResult.scanned === 0 && config.supabaseUrl) {
      console.log("[WA] DOM found 0 chats, scheduling re-learn");
      learnDomViaAI(tab.id).catch(function(){});
    }
    
    domResult.method = "dom";
    return domResult;
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Send WhatsApp Message (schema-aware) ──
async function sendWhatsAppMessage(phone, text) {
  try {
    var schema = await getSchema();
    var existingTabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    
    if (existingTabs.length > 0) {
      var tab = existingTabs[0];
      if (tab.status !== "complete") await waitForLoad(tab.id, 10000);
      await sleep(1500);

      var sendResult = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        args: [phone, text, schema],
        func: async function(phone, text, s) {
          function getSearchBox() {
            var selectors = [
              s.searchBox + ' [contenteditable="true"]',
              s.searchBox,
              '#side [contenteditable="true"]',
              '[title="Search input textbox"]',
              '[title="Cerca o inizia una nuova chat"]',
              '[title="Search or start new chat"]',
              '[role="textbox"][contenteditable="true"]',
            ];
            for (var sel of selectors) {
              var el = document.querySelector(sel);
              if (el) return el.querySelector ? (el.querySelector('[contenteditable="true"], input, textarea') || el) : el;
            }
            return null;
          }

          function clearAndType(field, value) {
            field.focus();
            if (typeof field.click === "function") field.click();
            if (field.isContentEditable || field.getAttribute("contenteditable") === "true") {
              document.execCommand("selectAll");
              document.execCommand("delete");
              field.textContent = "";
              document.execCommand("insertText", false, value);
              if ((field.textContent || "").trim() !== value) {
                field.textContent = value;
                field.dispatchEvent(new Event("input", { bubbles: true }));
              }
              return;
            }
            if ("value" in field) {
              field.value = "";
              field.dispatchEvent(new Event("input", { bubbles: true }));
              field.value = value;
              field.dispatchEvent(new Event("input", { bubbles: true }));
            }
          }

          // Search for phone
          var searchBox = getSearchBox();
          if (!searchBox) return { success: false, error: "Search box not found" };

          clearAndType(searchBox, phone);
          await new Promise(function(r) { setTimeout(r, 2000); });

          // Click first result
          var chats = document.querySelectorAll(s.chatItem + ', [role="listitem"], [role="row"]');
          var clicked = false;
          for (var c of chats) {
            var title = "";
            var span = c.querySelector("span[title]");
            if (span) title = span.getAttribute("title") || span.textContent || "";
            if (title.replace(/\D/g, "").includes(phone.replace(/\D/g, "").slice(-8))) {
              c.click();
              clicked = true;
              break;
            }
          }

          if (!clicked) {
            searchBox.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
            await new Promise(function(r) { setTimeout(r, 2000); });
          }

          // Type in compose box
          var composeSelectors = [
            s.composeBox,
            '[data-testid="conversation-compose-box-input"]',
            '#main footer [contenteditable="true"]',
            '[contenteditable="true"][data-tab]',
          ];
          var composeBox = null;
          for (var cs of composeSelectors) {
            composeBox = document.querySelector(cs);
            if (composeBox) break;
          }
          if (!composeBox) return { success: false, error: "Compose box not found" };

          clearAndType(composeBox, text);
          await new Promise(function(r) { setTimeout(r, 500); });

          // Click send
          var sendSelectors = [
            s.sendButton,
            '[data-testid="send"]',
            'button[aria-label*="Invia"]',
            'button[aria-label*="Send"]',
          ];
          var sendBtn = null;
          for (var ss of sendSelectors) {
            sendBtn = document.querySelector(ss);
            if (sendBtn) break;
          }
          if (sendBtn) {
            sendBtn.click();
          } else {
            composeBox.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
          }

          // Clear search
          var clearBtn = document.querySelector(s.searchClear);
          if (clearBtn) clearBtn.click();

          return { success: true };
        },
      });

      var result = sendResult?.[0]?.result;
      if (result?.success) return result;
      if (result?.error) return result;
    }

    // Fallback: open wa.me link
    var cleanPhone = phone.replace(/\D/g, "");
    var waUrl = "https://wa.me/" + cleanPhone + "?text=" + encodeURIComponent(text);
    var newTab = await safeCreateTab(waUrl, true);
    await waitForLoad(newTab.id, 15000);
    await sleep(3000);

    await chrome.scripting.executeScript({
      target: { tabId: newTab.id },
      func: function() {
        var sendBtn = document.querySelector('a[href*="send"]') || document.querySelector('[data-testid="send"]');
        if (sendBtn) sendBtn.click();
      },
    });

    return { success: true, method: "wa_me_link" };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Read Thread (schema-aware) ──
async function readChatThread(contactName, maxMessages) {
  try {
    var r = await getOrCreateWaTab();
    var schema = await getSchema();
    await sleep(r.reused ? 1500 : 5000);

    var results = await chrome.scripting.executeScript({
      target: { tabId: r.tab.id },
      args: [contactName, schema],
      func: async function(target, s) {
        function getSearchBox() {
          var selectors = [
            s.searchBox + ' [contenteditable="true"]',
            s.searchBox,
            '#side [contenteditable="true"]',
            '[title="Search input textbox"]',
            '[title="Cerca o inizia una nuova chat"]',
            '[role="textbox"][contenteditable="true"]',
          ];
          for (var sel of selectors) {
            var el = document.querySelector(sel);
            if (el) return el.querySelector ? (el.querySelector('[contenteditable="true"], input, textarea') || el) : el;
          }
          return null;
        }

        function clearAndType(field, value) {
          field.focus();
          if (typeof field.click === "function") field.click();
          if (field.isContentEditable || field.getAttribute("contenteditable") === "true") {
            document.execCommand("selectAll");
            document.execCommand("delete");
            field.textContent = "";
            document.execCommand("insertText", false, value);
            if ((field.textContent || "").trim() !== value) {
              field.textContent = value;
              field.dispatchEvent(new Event("input", { bubbles: true }));
            }
            return;
          }
          if ("value" in field) {
            field.value = "";
            field.dispatchEvent(new Event("input", { bubbles: true }));
            field.value = value;
            field.dispatchEvent(new Event("input", { bubbles: true }));
          }
        }

        function currentChatMatches(name) {
          var header = document.querySelector(s.mainHeader) || document.querySelector('#main header [dir="auto"]');
          var label = header ? (header.getAttribute("title") || header.textContent || "").trim() : "";
          return !!label && label.toLowerCase().includes(name.toLowerCase());
        }

        async function openChat(name) {
          if (currentChatMatches(name)) return { success: true };
          var searchBox = getSearchBox();
          if (!searchBox) return { success: false, error: "Search box not found" };
          clearAndType(searchBox, name);
          await new Promise(function(r) { setTimeout(r, 1500); });

          var chats = document.querySelectorAll(s.chatItem + ", " + (s.chatItemAlt || '[role="listitem"]'));
          var clicked = false;
          for (var c of chats) {
            var span = c.querySelector("span[title]");
            var title = span ? (span.getAttribute("title") || span.textContent || "").trim() : "";
            if (title && title.toLowerCase().includes(name.toLowerCase())) {
              (c.closest(s.chatItem) || c).click();
              clicked = true;
              break;
            }
          }
          if (!clicked) {
            searchBox.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
            await new Promise(function(r) { setTimeout(r, 1200); });
            clicked = currentChatMatches(name);
          }
          var clearBtn = document.querySelector(s.searchClear);
          if (clearBtn) clearBtn.click();
          if (!clicked) return { success: false, error: "Chat non trovata: " + name };
          await new Promise(function(r) { setTimeout(r, 2000); });
          return { success: true };
        }

        var openResult = await openChat(target);
        if (!openResult.success) return openResult;

        var panel = document.querySelector(s.conversationPanel) || document.querySelector("#main [role='application']") || document.querySelector("#main");
        return { success: true, html: panel ? panel.outerHTML : null };
      },
    });

    var scriptResult = results?.[0]?.result;
    if (!scriptResult?.success) return scriptResult || { success: false, error: "Script error" };

    if (scriptResult.html) {
      var config = await getConfig();
      if (config.supabaseUrl && config.anonKey) {
        var aiResult = await callAiExtract(scriptResult.html, "thread", config.supabaseUrl, config.anonKey, config.authToken);
        if (aiResult?.success && aiResult.items?.length > 0) {
          return {
            success: true,
            messages: aiResult.items.map(function(m) {
              return { direction: m.direction || "inbound", text: m.text || "", timestamp: m.timestamp || "", contact: m.contact || contactName };
            }),
            contact: contactName,
            method: "ai",
          };
        }
      }
    }

    // DOM fallback
    var domResults = await chrome.scripting.executeScript({
      target: { tabId: r.tab.id },
      args: [contactName, maxMessages || 50, schema],
      func: function(target, limit, s) {
        var msgEls = document.querySelectorAll(s.msgContainer);
        if (!msgEls.length) msgEls = document.querySelectorAll('[data-testid="msg-container"]');
        var msgs = [];
        var items = Array.from(msgEls).slice(-limit);
        for (var el of items) {
          var isOut = !!el.querySelector(s.msgOutCheck) || !!el.querySelector(s.msgOutSingle);
          var textEl = el.querySelector(s.msgText) || el.querySelector(".selectable-text span");
          var text = textEl?.textContent?.trim() || "";
          if (!text) continue;
          var timeEl = el.querySelector(s.msgMeta);
          msgs.push({ direction: isOut ? "outbound" : "inbound", text, timestamp: timeEl?.textContent?.trim() || "", contact: isOut ? "me" : target });
        }
        return { success: true, messages: msgs, contact: target, method: "dom" };
      },
    });
    return domResults?.[0]?.result || { success: false, error: "DOM fallback failed" };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Backfill Chat (schema-aware) ──
async function backfillChat(contactName, lastKnownText, maxScrolls) {
  var MAX_SCROLLS = maxScrolls || 30;
  try {
    var r = await getOrCreateWaTab();
    var schema = await getSchema();
    await sleep(r.reused ? 1500 : 5000);

    // Open chat first
    var openResult = await chrome.scripting.executeScript({
      target: { tabId: r.tab.id },
      args: [contactName, schema],
      func: async function(target, s) {
        function getSearchBox() {
          var selectors = [s.searchBox + ' [contenteditable="true"]', s.searchBox, '#side [contenteditable="true"]', '[role="textbox"][contenteditable="true"]'];
          for (var sel of selectors) { var el = document.querySelector(sel); if (el) return el.querySelector ? (el.querySelector('[contenteditable="true"]') || el) : el; }
          return null;
        }
        function clearAndType(field, value) {
          field.focus(); if (typeof field.click === "function") field.click();
          if (field.isContentEditable) { document.execCommand("selectAll"); document.execCommand("delete"); document.execCommand("insertText", false, value); return; }
          if ("value" in field) { field.value = value; field.dispatchEvent(new Event("input", { bubbles: true })); }
        }
        function currentChatMatches(name) {
          var h = document.querySelector(s.mainHeader) || document.querySelector('#main header [dir="auto"]');
          return h && (h.getAttribute("title") || h.textContent || "").toLowerCase().includes(name.toLowerCase());
        }
        if (currentChatMatches(target)) return { success: true };
        var sb = getSearchBox();
        if (!sb) return { success: false, error: "Search box not found" };
        clearAndType(sb, target);
        await new Promise(function(r) { setTimeout(r, 1500); });
        var chats = document.querySelectorAll(s.chatItem + ", " + (s.chatItemAlt || '[role="listitem"]'));
        for (var c of chats) {
          var span = c.querySelector("span[title]");
          var t = span ? (span.getAttribute("title") || "").trim() : "";
          if (t.toLowerCase().includes(target.toLowerCase())) { c.click(); break; }
        }
        await new Promise(function(r) { setTimeout(r, 2000); });
        var cl = document.querySelector(s.searchClear); if (cl) cl.click();
        return { success: currentChatMatches(target) };
      },
    });

    if (!openResult?.[0]?.result?.success) return openResult?.[0]?.result || { success: false, error: "Open failed" };

    var allMessages = [];
    var foundLast = false;
    var scrollDelays = [1, 2, 1.5, 3, 1, 2.5, 2, 1, 3, 1.5];
    var scrollIdx = 0;

    for (; scrollIdx < MAX_SCROLLS && !foundLast; scrollIdx++) {
      var scrollResult = await chrome.scripting.executeScript({
        target: { tabId: r.tab.id },
        args: [contactName, lastKnownText || "", schema],
        func: function(contact, lastText, s) {
          var panel = document.querySelector(s.conversationPanel) || document.querySelector("#main [role='application']") || document.querySelector("#main");
          if (!panel) return { success: false, error: "Panel not found" };
          var scrollContainer = panel.closest('[data-testid="conversation-panel-body"]') || panel.parentElement;
          if (scrollContainer) scrollContainer.scrollTop = 0;

          var msgEls = document.querySelectorAll(s.msgContainer);
          if (!msgEls.length) msgEls = document.querySelectorAll('[data-testid="msg-container"]');
          var msgs = [];
          var hitLast = false;
          for (var el of msgEls) {
            var isOut = !!el.querySelector(s.msgOutCheck) || !!el.querySelector(s.msgOutSingle);
            var textEl = el.querySelector(s.msgText) || el.querySelector(".selectable-text span");
            var text = textEl?.textContent?.trim() || "";
            if (!text) continue;
            if (lastText && text === lastText) { hitLast = true; break; }
            var timeEl = el.querySelector(s.msgMeta);
            msgs.push({ direction: isOut ? "outbound" : "inbound", text, timestamp: timeEl?.textContent?.trim() || "", contact: isOut ? "me" : contact });
          }
          return { success: true, messages: msgs, foundLast: hitLast, totalInDom: msgEls.length };
        },
      });

      var res = scrollResult?.[0]?.result;
      if (!res?.success) break;
      if (res.messages?.length) {
        for (var m of res.messages) {
          var isDup = allMessages.some(function(ex) { return ex.text === m.text && ex.timestamp === m.timestamp; });
          if (!isDup) allMessages.push(m);
        }
      }
      if (res.foundLast) { foundLast = true; break; }
      var delay = scrollDelays[scrollIdx % scrollDelays.length] * 1000;
      await sleep(delay);
    }

    return { success: true, messages: allMessages, contact: contactName, foundLast, scrollCount: scrollIdx };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Diagnostic DOM (schema-aware, rich) ──
async function diagnosticDom() {
  try {
    var r = await getOrCreateWaTab();
    var schema = await getSchema();
    await sleep(r.reused ? 1000 : 4000);
    var results = await chrome.scripting.executeScript({
      target: { tabId: r.tab.id },
      args: [schema],
      func: function(s) {
        var diag = {};
        diag.url = location.href;
        diag.title = document.title;
        diag.hasQR = false;
        var qrSels = (s.qrCode || "").split(",").map(function(x){return x.trim();});
        for (var q of qrSels) { if (q && document.querySelector(q)) { diag.hasQR = true; break; } }
        diag.hasSidebar = !!document.querySelector(s.sidebar);
        diag.hasChatList = !!document.querySelector(s.chatList);
        diag.hasSide = !!document.querySelector("#side");
        diag.hasPaneSide = !!document.querySelector("#pane-side");
        diag.chatItems = document.querySelectorAll(s.chatItem).length;
        diag.chatItemsAlt = document.querySelectorAll(s.chatItemAlt || "___none___").length;
        diag.listItems = document.querySelectorAll('[role="listitem"]').length;
        diag.rowItems = document.querySelectorAll('[role="row"]').length;
        diag.unreadBadges = document.querySelectorAll(s.unreadBadge).length;
        diag.bodyChildCount = document.body.children.length;
        diag.appDiv = !!document.querySelector("#app");
        diag.allTestIds = Array.from(new Set(Array.from(document.querySelectorAll("[data-testid]")).map(function(e){return e.getAttribute("data-testid");}))).sort().slice(0, 50);
        diag.allIds = Array.from(new Set(Array.from(document.querySelectorAll("[id]")).map(function(e){return e.id;}))).sort().slice(0, 30);
        diag.schemaUsed = { sidebar: s.sidebar, chatItem: s.chatItem, chatList: s.chatList, learnedAt: s.learnedAt };
        return { success: true, diagnostic: diag };
      },
    });
    return results?.[0]?.result || { success: false, error: "no result" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ══════════════════════════════════════════════
//  LIFECYCLE & MESSAGE HANDLER
// ══════════════════════════════════════════════

chrome.runtime.onInstalled.addListener(function() { syncBridgeAcrossOpenTabs().catch(function(){}); });
chrome.runtime.onStartup.addListener(function() { syncBridgeAcrossOpenTabs().catch(function(){}); });

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === "complete" && tab.url && isAppUrl(tab.url)) {
    injectBridgeIntoTab(tabId).catch(function(){});
  }
});

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.source !== "wa-content-bridge") return false;

  if (msg.action === "ping") {
    sendResponse({ success: true, version: "4.0-selfheal" });
    return false;
  }

  if (msg.action === "setConfig") {
    chrome.storage.local.set({
      supabaseUrl: msg.supabaseUrl || "",
      anonKey: msg.anonKey || "",
      authToken: msg.authToken || "",
    }).then(function() { sendResponse({ success: true }); });
    return true;
  }

  if (msg.action === "verifySession") {
    verifySession().then(sendResponse);
    return true;
  }

  if (msg.action === "sendWhatsApp") {
    if (!msg.phone || !msg.text) { sendResponse({ success: false, error: "phone e text richiesti" }); return false; }
    sendWhatsAppMessage(msg.phone, msg.text).then(sendResponse);
    return true;
  }

  if (msg.action === "readUnread") {
    readUnreadMessages().then(sendResponse);
    return true;
  }

  if (msg.action === "diagnosticDom") {
    diagnosticDom().then(sendResponse);
    return true;
  }

  if (msg.action === "learnDom") {
    (async function() {
      try {
        var r = await getOrCreateWaTab();
        await sleep(r.reused ? 1000 : 4000);
        var result = await learnDomViaAI(r.tab.id);
        sendResponse(result);
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === "readThread") {
    if (!msg.contact) { sendResponse({ success: false, error: "contact richiesto" }); return false; }
    readChatThread(msg.contact, msg.maxMessages || 50).then(sendResponse);
    return true;
  }

  if (msg.action === "backfillChat") {
    if (!msg.contact) { sendResponse({ success: false, error: "contact richiesto" }); return false; }
    backfillChat(msg.contact, msg.lastKnownText || "", msg.maxScrolls || 30).then(sendResponse);
    return true;
  }

  sendResponse({ success: false, error: "Azione sconosciuta: " + msg.action });
  return false;
});
