# Piano di Ristrutturazione: Sistema Perfetto VoiceTranslate

## Problemi Identificati

### PROBLEMA 1: Classroom Mode — Il "maestro" parla nella lingua sbagliata
Il translate API (`app/api/translate/route.js`) NON riceve informazioni sulla modalità (classroom/conversation/etc). Il system prompt tratta ogni traduzione come "interprete vocale" generico. In classroom mode, un utente thai che impara l'inglese dovrebbe ricevere spiegazioni IN THAI, non una traduzione generica.

**Root cause**: `useTranslation.js` non passa `roomMode` alla API. La API non ha prompt diversi per classroom.

### PROBLEMA 2: Landing Page tutta in italiano
`app/landing/page.js` ha TUTTO hardcoded in italiano — FEATURES, PLANS, FAQ, testi del hero, navigation. Zero uso di `t()` o `L()`. Stesso per `app/admin/page.js`.

### PROBLEMA 3: Email template in italiano
`app/api/auth/route.js` riga 38-54 — l'email di verifica è tutta in italiano.

### PROBLEMA 4: Layout/meta hardcoded
`app/layout.js` ha titolo e descrizione mix italiano/inglese.

### PROBLEMA 5: Offline page solo in inglese
`public/sw.js` ha la offline page hardcoded in inglese.

---

## Piano di Implementazione

### Step 1: Fix Classroom Mode (translate API + useTranslation hook)
**File**: `app/hooks/useTranslation.js`
- Aggiungere `roomMode` al body della fetch `/api/translate`
- Passare anche `myLang` (lingua nativa dell'utente) come campo separato

**File**: `app/api/translate/route.js`
- Ricevere `roomMode` e `nativeLang` dal body
- Se `roomMode === 'classroom'`: cambiare il system prompt da "interprete vocale" a "insegnante di lingua" che spiega nella lingua nativa dello studente

### Step 2: Internazionalizzare Landing Page
**File**: `app/landing/page.js`
- Importare `t` da `../lib/i18n.js`
- Aggiungere detection lingua da `navigator.language` e da localStorage `vt-prefs`
- Aggiungere language switcher nel nav
- Spostare tutti i testi (FEATURES, PLANS, FAQ) su chiavi i18n

**File**: `app/lib/i18n.js`
- Aggiungere ~80 nuove chiavi per landing page per TUTTE le 26 lingue

### Step 3: Internazionalizzare Admin Page
**File**: `app/admin/page.js`
- Stessa procedura della landing

### Step 4: Internazionalizzare Email Templates
**File**: `app/api/auth/route.js`
- Usare `t(lang, key)` per subject e body dell'email
- Il `lang` viene dal body della request (già presente)

### Step 5: Fix Layout Meta
**File**: `app/layout.js`
- Usare chiavi i18n per titolo e descrizione

### Step 6: Build + Test + Commit + Push
