# VoiceTranslate Legal & Compliance Setup

This document outlines the legal pages and GDPR features that have been added to VoiceTranslate.

## Files Created

### 1. Terms of Service Page
**Location:** `/app/terms/page.js`
**Access:** `https://your-domain.com/terms`

Features:
- Professional legal document covering service description, account registration, acceptable use policy
- Subscription tiers (FREE, STARTER, PRO)
- API key usage disclaimer
- Intellectual property and disclaimers
- Limitation of liability
- Italian law governing clause
- Contact information for support

### 2. Privacy Policy Page
**Location:** `/app/privacy/page.js`
**Access:** `https://your-domain.com/privacy`

Features:
- GDPR-compliant privacy policy
- Detailed data collection and usage practices
- Third-party service integrations (OpenAI, Anthropic, Google, ElevenLabs, Stripe, Supabase, Vercel)
- Data storage and security information
- Cookies and localStorage details
- User rights under GDPR (access, rectification, erasure, data portability, objection)
- Data retention policy
- Children's privacy (under 16 not permitted)
- DPO contact information

### 3. Cookie Consent Banner
**Location:** `/app/components/CookieConsent.js`
**Usage:** Automatically included in `/app/layout.js`

Features:
- GDPR-compliant consent banner
- Appears at bottom of screen with smooth slide-up animation
- Two options: "Accept All" and "Only Essential"
- Stores user choice in localStorage (`vt-cookie-consent`)
- Links to Privacy Policy
- Does not show again if consent has been previously given
- Dark theme matching app design

**localStorage Keys:**
- `vt-cookie-consent` - User choice: 'all' or 'essential'
- `vt-cookie-consent-date` - ISO timestamp of consent

### 4. GDPR Data Export Endpoint
**Location:** `/app/api/user/export/route.js`
**Access:** `GET /api/user/export` with Bearer token authorization

Features:
- GDPR Article 20 - Right to Data Portability
- Supports both GET (Bearer token) and POST (token in body) methods
- Returns all user data in JSON format
- Includes:
  - User profile (email, name, avatar, language, tier, credits)
  - Subscription data (from Supabase)
  - Usage logs (API calls, costs)
  - Translation history metadata
  - Account creation/login timestamps
- Excludes sensitive data (encrypted API keys)
- Automatic file download with email-safe filename
- Comprehensive error handling

**Usage Example:**

```javascript
// In your frontend
const token = localStorage.getItem('vt-token');

const response = await fetch('/api/user/export', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const blob = await response.blob();
const url = window.URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'my-data-export.json';
a.click();
```

Or via POST:

```javascript
const response = await fetch('/api/user/export', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ token })
});
```

## Design Consistency

All pages use the dark theme matching VoiceTranslate's existing design:
- Background: `#09090b`
- Text: `#e4e4e7`
- Accent (orange): `#f97316`
- Border/secondary: `#27272a`, `#71717a`

Mobile responsive design with proper padding and readable font sizes.

## Integration Notes

### Adding Links to Legal Pages

Add links in your navigation, footer, or account settings:

```jsx
import Link from 'next/link';

<Link href="/terms">Terms of Service</Link>
<Link href="/privacy">Privacy Policy</Link>
```

### Configuring Email Contacts

Update the following email addresses in the pages (currently set to examples):
- `support@voicetranslate.app` - General support
- `privacy@voicetranslate.app` - Data Protection Officer (DPO)

### Cookie Consent Handling

The banner automatically appears to users who haven't consented yet. To programmatically check consent:

```javascript
function hasAcceptedAllCookies() {
  const consent = localStorage.getItem('vt-cookie-consent');
  return consent === 'all';
}

function hasAcceptedEssentialOnly() {
  const consent = localStorage.getItem('vt-cookie-consent');
  return consent === 'essential';
}
```

## GDPR Compliance Checklist

- [x] Terms of Service page created
- [x] Privacy Policy (GDPR-compliant) created
- [x] Cookie Consent banner implemented
- [x] Data export endpoint (Article 20) implemented
- [x] Data deletion functionality (Article 17) - already in `/api/user` route
- [x] DPO contact information documented
- [x] Data storage in EU servers (Supabase EU)
- [x] Encryption for sensitive data
- [x] Third-party service documentation

## Testing

1. **Terms Page:** Visit `/terms` to verify formatting and links
2. **Privacy Page:** Visit `/privacy` to verify GDPR clauses and links
3. **Cookie Banner:** Clear `vt-cookie-consent` localStorage key and refresh page
4. **Data Export:** Call `/api/user/export` with valid Bearer token

## Notes

- All content is in English (standard for legal documents across EU services)
- Effective date set to March 2026
- Governing law: Italian law (EU GDPR applies)
- Pages are fully mobile responsive
- Back button functionality works on both pages
- All external links (to Privacy Policy) use Next.js Link component

## Future Enhancements

Consider adding:
- Multi-language versions of legal pages (optional for EU compliance)
- Automated legal document updates
- Cookie preference center (granular control)
- Audit logs for GDPR requests
- Automated data deletion scheduled tasks
