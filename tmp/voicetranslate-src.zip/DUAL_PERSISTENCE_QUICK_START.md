# Dual Persistence - Quick Start Guide

## Import & Use

```javascript
'use client';
import { useDualPersist } from '@/app/hooks/useDualPersist';
import { useAuth } from '@/app/hooks/useAuth';

export function MyComponent() {
  const { token } = useAuth();
  const { prefs, updatePref, setPrefs, resetPrefs } = useDualPersist(token);

  return (
    <div>
      <p>Language: {prefs.lang}</p>
      <button onClick={() => updatePref('lang', 'it')}>
        Switch to Italian
      </button>
    </div>
  );
}
```

## API Reference

### useDualPersist(userToken)

**Parameters:**
- `userToken` (string|null) - Auth token from useAuth hook

**Returns:**
```javascript
{
  prefs: Object,           // Current preferences
  setPrefs: Function,      // Replace entire prefs or call with function
  updatePref: Function,    // Update single preference
  resetPrefs: Function     // Clear all preferences (logout)
}
```

## Usage Patterns

### Read Preference
```javascript
const lang = prefs.lang || 'en';
```

### Update Single Preference
```javascript
updatePref('lang', 'it');
updatePref('voice', 'en_US_1');
updatePref('theme', 'dark');
```

### Update Multiple Preferences
```javascript
setPrefs(prev => ({
  ...prev,
  lang: 'it',
  voice: 'en_US_1'
}));

// Or replace entirely:
setPrefs({ lang: 'it', voice: 'en_US_1' });
```

### On Logout
```javascript
function handleLogout() {
  resetPrefs();
  // ... other logout logic
}
```

## What Gets Synced?

When authenticated, these properties automatically sync to Supabase:
- `lang` - Language code
- `name` - User name
- `avatar` - Avatar URL
- `tier` - Subscription tier
- `voice` - TTS voice ID
- `ttsEngine` - TTS provider
- `autoSpeak` - Auto-play flag
- `provider` - LLM provider
- `model` - LLM model
- `theme` - UI theme

## Behavior

| Scenario | Result |
|----------|--------|
| User edits pref (online) | localStorage updated instantly ✓ + cloud sync in background |
| User edits pref (offline) | localStorage updated instantly ✓, sync on reconnect |
| User logs in | Cloud + local merged (local wins), synced back to cloud |
| User logs out | localStorage cleared, state reset |
| DB unavailable | Changes saved locally, cloud sync silently fails |

## Debugging

### Check localStorage
```javascript
// Browser console
JSON.parse(localStorage.getItem('vt-prefs'))
// { lang: 'it', voice: 'en_US_1', ... }
```

### Check last sync time
```javascript
localStorage.getItem('vt-last-sync')
// "2025-03-06T12:34:56.789Z"
```

### Monitor network calls
```
PUT /api/user
Authorization: Bearer <token>
{
  "action": "sync-prefs",
  "prefs": { ... }
}
```

## Migration from Old Pattern

**Before:**
```javascript
const [prefs, setPrefs] = useState({});
useEffect(() => {
  const saved = localStorage.getItem('vt-prefs');
  if (saved) setPrefs(JSON.parse(saved));
}, []);
const savePrefs = (p) => {
  setPrefs(p);
  localStorage.setItem('vt-prefs', JSON.stringify(p));
};
```

**After:**
```javascript
const { prefs, setPrefs } = useDualPersist(token);
// That's it! Everything else is automatic.
```

## Common Patterns

### Settings Form
```javascript
const { prefs, updatePref } = useDualPersist(token);

<select value={prefs.lang} onChange={e => updatePref('lang', e.target.value)}>
  <option value="en">English</option>
  <option value="it">Italiano</option>
</select>
```

### Dropdown with Voice Selection
```javascript
<select value={prefs.voice} onChange={e => updatePref('voice', e.target.value)}>
  <option value="">Default</option>
  <option value="en_US_1">American English</option>
  <option value="en_GB_1">British English</option>
</select>
```

### Theme Toggle
```javascript
<button onClick={() => updatePref('theme', prefs.theme === 'dark' ? 'light' : 'dark')}>
  {prefs.theme === 'dark' ? '☀️' : '🌙'}
</button>
```

### Conditional Rendering Based on Prefs
```javascript
{prefs.autoSpeak && <audio src={audioUrl} autoPlay />}
```

## No Network Calls Needed In Components

The hook handles all persistence automatically:
- ✓ Reads from localStorage (instant)
- ✓ Writes to localStorage (instant)
- ✓ Background Supabase sync (non-blocking)
- ✓ Merge on login (automatic)

Just call `updatePref()` and everything else is handled!

## Performance

- Read latency: <1ms (localStorage)
- Write latency: <5ms (localStorage)
- Network calls: ~300 bytes per sync
- Update frequency: No rate limiting on component level (API rate limited at 60 req/min)

## Troubleshooting

**Preferences not persisting:**
- Check localStorage is enabled (not in private/incognito mode)
- Check browser quota (usually 5-10 MB)
- Check console for errors

**Cloud sync not working:**
- Check network tab for PUT requests to /api/user
- Verify token is valid (useAuth hook)
- Check browser console for sync warnings

**Preferences not merging on login:**
- Make sure useAuth provides token before useDualPersist
- Check that userToken is being passed to hook
- Verify Supabase user_settings table has user's data

---

For detailed documentation, see **DUAL_PERSISTENCE_IMPLEMENTATION.md**
