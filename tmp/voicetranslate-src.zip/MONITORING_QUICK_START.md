# Monitoring Quick Start Guide

## What Was Installed

✓ **Sentry** (@sentry/nextjs) - Error tracking and performance monitoring
✓ **Plausible** - Privacy-first analytics (no cookies, GDPR compliant)

## Files Created/Modified

### New Files
- `sentry.client.config.js` - Client-side error tracking
- `sentry.server.config.js` - Server-side error tracking
- `sentry.edge.config.js` - Edge middleware error tracking
- `app/global-error.js` - Global error boundary UI
- `app/lib/analytics.js` - Analytics event tracking helper

### Modified Files
- `next.config.mjs` - Added Sentry integration & CSP headers
- `app/layout.js` - Added Plausible script
- `.env.example` - Added environment variables

## Setup (5 minutes)

### 1. Sentry Setup
```bash
# 1. Create account at https://sentry.io
# 2. Create new Next.js project
# 3. Copy your DSN, then add to .env.local:

NEXT_PUBLIC_SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx
SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx
SENTRY_ORG=voicetranslate
SENTRY_PROJECT=voicetranslate
```

### 2. Plausible Setup
```bash
# 1. Create account at https://plausible.io
# 2. Add your domain
# 3. Add to .env.local:

NEXT_PUBLIC_PLAUSIBLE_DOMAIN=voicetranslate.app
```

### 3. Deploy
```bash
npm run build
npm start
# Sentry only activates in production!
```

## Track Analytics Events

```javascript
import { trackEvent, EVENTS } from '@/lib/analytics';

// Track key actions
trackEvent(EVENTS.SIGNUP);
trackEvent(EVENTS.TRANSLATION);
trackEvent(EVENTS.CREDITS_PURCHASED);

// Or custom events
trackEvent('CustomEvent', { property: 'value' });
```

## Available Events

```javascript
EVENTS.SIGNUP                    // User registration
EVENTS.LOGIN                     // User login
EVENTS.ROOM_CREATED              // Room creation
EVENTS.ROOM_JOINED               // Room join
EVENTS.TRANSLATION               // Translation action
EVENTS.TTS_PLAYED                // Text-to-speech playback
EVENTS.VOICE_CLONED              // Voice cloning
EVENTS.SUBSCRIPTION_STARTED       // Subscription purchase
EVENTS.CREDITS_PURCHASED         // Credit purchase
EVENTS.SETTINGS_CHANGED           // Settings update
EVENTS.CLASSROOM_STARTED          // Classroom session
EVENTS.LENDING_CREATED            // Lending feature usage
```

## Error Handling

Errors are automatically captured by:
- ✓ Global error boundary (`app/global-error.js`)
- ✓ API route error responses
- ✓ Client-side React errors
- ✓ Server-side errors

No manual setup needed — just deploy!

## View Dashboards

- **Sentry Errors**: https://sentry.io (after first production error)
- **Plausible Analytics**: https://plausible.io (within 24 hours)

## Troubleshooting

**Sentry not working?**
- Only activates in production (`NODE_ENV=production`)
- Check DSN is correct in Sentry dashboard
- Verify `NEXT_PUBLIC_SENTRY_DSN` is set

**Plausible not tracking?**
- Verify domain matches in Plausible dashboard
- Wait 24-48 hours for first data to appear
- Check `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set

**Build issues?**
```bash
# Clear cache and rebuild
rm -rf .next node_modules/.cache
npm run build
```

## Next Steps

1. ✓ Copy `.env.example` to `.env.local`
2. ✓ Add Sentry DSN and Plausible domain
3. ✓ Deploy to production
4. ✓ Monitor incoming errors and events

## Full Documentation

See `MONITORING_SETUP.md` for complete details.
