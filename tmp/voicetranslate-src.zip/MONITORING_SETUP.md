# Monitoring & Analytics Setup for VoiceTranslate

This document covers the integration of **Sentry** (error tracking) and **Plausible** (privacy-first analytics) into your VoiceTranslate application.

## Table of Contents

1. [Sentry Error Tracking](#sentry-error-tracking)
2. [Plausible Analytics](#plausible-analytics)
3. [Environment Variables](#environment-variables)
4. [Usage Examples](#usage-examples)
5. [Testing in Development](#testing-in-development)

---

## Sentry Error Tracking

### Overview

Sentry provides real-time error tracking and performance monitoring for your Next.js application. It captures unhandled exceptions, performance metrics, and provides session replay on errors.

### Features Enabled

- **Error Tracking**: Automatically captures unhandled exceptions across client and server
- **Performance Monitoring**: 10% sample rate for performance transactions
- **Session Replay**: Video-like replay of user sessions when errors occur (on errors only)
- **Breadcrumbs**: Tracks user actions leading up to errors
- **Environment Detection**: Separate handling for development and production

### Files Added

1. **`sentry.client.config.js`** - Client-side configuration
   - Enables session replay on errors (10% sample rate)
   - Filters out common network-related noise
   - Filters debug-level console breadcrumbs

2. **`sentry.server.config.js`** - Server-side configuration
   - Ignores connection-related errors (ECONNRESET, ECONNREFUSED, ETIMEDOUT)

3. **`sentry.edge.config.js`** - Edge middleware configuration
   - Covers edge runtime errors

4. **`app/global-error.js`** - Global error boundary
   - Provides a user-friendly error UI with a "Try again" button
   - Automatically sends error to Sentry

### Next.js Configuration Updated

The `next.config.mjs` file was updated to:
- Import `withSentryConfig` from `@sentry/nextjs`
- Wrap the Next.js configuration with Sentry
- Configure source map handling for better error tracking
- Update CSP headers to allow Sentry connections

### Setup Steps

1. **Create a Sentry Project**
   - Go to [sentry.io](https://sentry.io)
   - Create a new project for "Next.js"
   - Note your DSN (Data Source Name)

2. **Set Environment Variables** (in `.env.local` or deployment platform)
   ```bash
   NEXT_PUBLIC_SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx
   SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx  # Optional: for server-side
   SENTRY_ORG=voicetranslate
   SENTRY_PROJECT=voicetranslate
   SENTRY_AUTH_TOKEN=xxxxx  # Optional: for source map uploads
   ```

3. **Deploy to Production**
   - Sentry only activates in production (`NODE_ENV=production`)
   - In development, Sentry is disabled and logs to console
   - First deploy will show a deprecation warning about `disableLogger` - this is safe to ignore

### Viewing Errors in Sentry

1. Log into your Sentry dashboard
2. Navigate to "Issues" to see error reports
3. Click an issue to view:
   - Stack trace
   - Breadcrumbs (user actions leading up to error)
   - Session replay (if available)
   - Affected users and devices
   - Release information

---

## Plausible Analytics

### Overview

Plausible is a privacy-first, GDPR-compliant analytics solution that doesn't use cookies or collect personal data. It's designed to be lightweight and ethical.

### Features

- **No Cookies**: Completely cookieless analytics
- **GDPR Compliant**: No consent banner needed (unlike Google Analytics)
- **Lightweight**: Minimal impact on page load performance
- **Event Tracking**: Custom events for key user actions
- **Simple Dashboard**: Easy-to-understand analytics

### Files Added

1. **`app/lib/analytics.js`** - Analytics helper library
   - `trackEvent(name, props)` - Track custom events
   - `trackPageView(url)` - Track page navigation (for SPAs)
   - `EVENTS` object - Pre-defined event names for VoiceTranslate

2. **`app/layout.js`** - Updated to include Plausible script
   - Script is only loaded if `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set
   - Placed in `<head>` section with `defer` attribute

3. **`next.config.mjs`** - Updated CSP headers
   - Allows loading from `plausible.io`
   - Allows connecting to `plausible.io`

### Pre-defined Events

The following events are available through the `EVENTS` constant:

```javascript
import { trackEvent, EVENTS } from '@/lib/analytics';

// Event tracking examples:
trackEvent(EVENTS.SIGNUP);                    // User signs up
trackEvent(EVENTS.LOGIN);                     // User logs in
trackEvent(EVENTS.ROOM_CREATED);              // User creates a room
trackEvent(EVENTS.ROOM_JOINED);               // User joins a room
trackEvent(EVENTS.TRANSLATION);               // User performs translation
trackEvent(EVENTS.TTS_PLAYED);                // User plays text-to-speech
trackEvent(EVENTS.VOICE_CLONED);              // User clones a voice
trackEvent(EVENTS.SUBSCRIPTION_STARTED);      // User starts subscription
trackEvent(EVENTS.CREDITS_PURCHASED);         // User purchases credits
trackEvent(EVENTS.SETTINGS_CHANGED);          // User changes settings
trackEvent(EVENTS.CLASSROOM_STARTED);         // Classroom session started
trackEvent(EVENTS.LENDING_CREATED);           // Lending feature used
```

### Setup Steps

1. **Create a Plausible Account**
   - Go to [plausible.io](https://plausible.io)
   - Sign up for a free or paid plan
   - Add your domain name

2. **Set Environment Variable** (in `.env.local` or deployment platform)
   ```bash
   NEXT_PUBLIC_PLAUSIBLE_DOMAIN=voicetranslate.app
   ```

3. **Verify Installation**
   - Deploy to production
   - Wait a few minutes
   - Check Plausible dashboard for incoming events
   - Look for "Waiting for first event" message to disappear

### Using Event Tracking in Your Code

#### Example 1: Track signup completion
```javascript
'use client';

import { trackEvent, EVENTS } from '@/lib/analytics';

export function SignupForm() {
  const handleSubmit = async (e) => {
    e.preventDefault();
    // ... form submission logic ...
    trackEvent(EVENTS.SIGNUP);
  };

  return <form onSubmit={handleSubmit}>{/* ... */}</form>;
}
```

#### Example 2: Track custom events with properties
```javascript
trackEvent(EVENTS.TRANSLATION, {
  source_language: 'en',
  target_language: 'es',
  duration_ms: 2500,
});
```

#### Example 3: Track page navigation in SPA
```javascript
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { trackPageView } from '@/lib/analytics';

export function useAnalyticsPageView() {
  const router = useRouter();

  useEffect(() => {
    const pathname = window.location.pathname;
    trackPageView(pathname);
  }, []);
}
```

### Viewing Analytics in Plausible

1. Log into your Plausible dashboard
2. You'll see:
   - **Visitors**: Real-time visitor count
   - **Pageviews**: Total pageviews
   - **Bounce rate**: Single-page sessions
   - **Session duration**: Average time on site
   - **Top pages**: Most visited pages
   - **Goals/Events**: Custom events you track

---

## Environment Variables

Add these to your `.env.local` file for local development, or configure them in your deployment platform (Vercel, etc.):

```bash
# Error Tracking (Sentry) — OPTIONAL in development, REQUIRED for production
NEXT_PUBLIC_SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx
SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxxx
SENTRY_ORG=voicetranslate
SENTRY_PROJECT=voicetranslate
SENTRY_AUTH_TOKEN=xxxxx

# Analytics (Plausible) — OPTIONAL, only loads if set
NEXT_PUBLIC_PLAUSIBLE_DOMAIN=voicetranslate.app
```

### Notes

- **`NEXT_PUBLIC_*` variables**: These are exposed to the browser (don't include secrets)
- **Sentry in Development**: Disabled by default (only enables in production)
- **Plausible in Development**: Script only loads if `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set
- **Graceful Degradation**: If env vars aren't set, the app continues to work normally

---

## Usage Examples

### Sentry Error Tracking

#### Automatic Error Handling

Errors are automatically captured by:
- Global error boundary (`app/global-error.js`)
- API route error responses
- Client-side React error boundaries

#### Manual Error Capture

```javascript
import * as Sentry from '@sentry/nextjs';

try {
  // Some code that might fail
  riskyOperation();
} catch (error) {
  // Manually send to Sentry
  Sentry.captureException(error);

  // Or create a custom message
  Sentry.captureMessage('Something unexpected happened', 'error');
}
```

#### Add Context to Errors

```javascript
import * as Sentry from '@sentry/nextjs';

Sentry.setUser({
  id: user.id,
  email: user.email,
  username: user.username,
});

Sentry.captureException(error);
// Now Sentry will show which user experienced the error
```

### Plausible Event Tracking

#### Track Form Submissions

```javascript
import { trackEvent, EVENTS } from '@/lib/analytics';

export function PaymentForm() {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Process payment...
    trackEvent(EVENTS.CREDITS_PURCHASED, {
      credits: 1000,
      plan: 'pro',
    });
  };

  return <form onSubmit={handleSubmit}>{/* ... */}</form>;
}
```

#### Track User Actions

```javascript
import { trackEvent, EVENTS } from '@/lib/analytics';

export function VoiceCloneButton({ onSuccess }) {
  const handleClick = async () => {
    try {
      await performVoiceCloning();
      trackEvent(EVENTS.VOICE_CLONED, {
        voice_name: 'Alice',
        language: 'English',
      });
      onSuccess();
    } catch (error) {
      console.error(error);
    }
  };

  return <button onClick={handleClick}>Clone Voice</button>;
}
```

---

## Testing in Development

### Test Sentry (Development Mode)

Even though Sentry is disabled in development, you can test it:

```javascript
// In a page or component
import * as Sentry from '@sentry/nextjs';

export default function TestPage() {
  const handleError = () => {
    try {
      throw new Error('Test error from development');
    } catch (e) {
      Sentry.captureException(e);
      console.log('Error sent to Sentry (check browser console)');
    }
  };

  return <button onClick={handleError}>Test Sentry Error</button>;
}
```

### Test Plausible in Development

Add to your `.env.local`:
```bash
NEXT_PUBLIC_PLAUSIBLE_DOMAIN=localhost:3000
```

Then check the browser console for the Plausible script:
```javascript
// In browser console
console.log(window.plausible);  // Should be a function
window.plausible('TestEvent', { props: { test: true } });
```

### Verify CSP Headers

Check that CSP headers allow Sentry and Plausible:

```bash
# Terminal
curl -I http://localhost:3000 | grep -A 3 "Content-Security-Policy"

# Should show:
# script-src 'self' ... https://plausible.io
# connect-src 'self' ... https://plausible.io https://*.sentry.io
```

---

## Troubleshooting

### Sentry Not Capturing Errors

1. Ensure `NODE_ENV=production` in deployment
2. Check that `NEXT_PUBLIC_SENTRY_DSN` is set and valid
3. Verify Sentry project exists and is active
4. Check browser console for CORS or CSP errors
5. Ensure CSP allows `https://*.sentry.io` connections

### Plausible Not Showing Events

1. Verify `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set correctly
2. Check that your domain is added in Plausible dashboard
3. Allow 24-48 hours for historical data to appear
4. Verify script is loaded: Open DevTools → Sources → Search "plausible"
5. Check browser console for CORS or CSP errors

### Build Fails

If you see an error related to Sentry during build:
- Ensure `@sentry/nextjs` is installed: `npm ls @sentry/nextjs`
- Clear `.next` cache: `rm -rf .next && npm run build`
- Check that `SENTRY_AUTH_TOKEN` is set if uploading source maps

---

## Best Practices

### Error Tracking

- Keep `tracesSampleRate` at 10% to balance insights vs. cost
- Use source maps to get readable stack traces
- Set user context when available for better issue correlation
- Create custom alerts for critical errors
- Review and close resolved issues regularly

### Analytics

- Use event names that match your business goals
- Include relevant properties with events (language pair, etc.)
- Don't track PII (personally identifiable information)
- Set up goals in Plausible dashboard for key metrics
- Review analytics weekly to identify trends

---

## Support

- **Sentry Docs**: https://docs.sentry.io/platforms/javascript/guides/nextjs/
- **Plausible Docs**: https://plausible.io/docs
- **Next.js Docs**: https://nextjs.org/docs

---

Last updated: March 2026
